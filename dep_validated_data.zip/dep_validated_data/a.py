#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import codecs
import re
import locale
from os import listdir
from os.path import isfile,join
#sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)
from ssfAPI_minimal import *
import pickle
import numpy as np

##############################################################################################################################
def wrds_samechunk(wrd_index,WordIndicesAlreadyAligned,ParseResult):
    res = []
    for i in range(len(ParseResult['sentences'][0]['words'])):
        if i not in WordIndicesAlreadyAligned:
            if ParseResult['sentences'][0]['words'][i][1]['ChunkType'] == ParseResult['sentences'][0]['words'][wrd_index][1]['ChunkType']:
                res.append(i)
    return res
#


def ssf_to_dic(file_name):
    #print 'sen',
    #print sen

    d = Document('/tmp/chunk_expand.txt')
#    print d.fileName
    all_sen = []
    for tree in d.nodeList :
        parse_output = {}
 #       print tree.text
        node_name = {}
        chunk_id = {}
        pos = {}
        lemma = {}
        chunk_type = {}
        parse_output = {}
        parse_output['text'] = tree.generateSentence()
        parse_output['dependencies']=[]
        node_index = 1
        sen = tree.generateSentence()
        for node in tree.nodeList :
            #print "\n*************node.lex***************"
            #print node.lex
            pos[node_index-1] = node.type
            lemma[node_index - 1] = node.morphroot
            #print node.getAttribute('chunkType')
            #print ''
            chunk_type[node_index - 1] = node.getAttribute('chunkType').split(":")[1]
            tmp = []
            relation_parent = node.getAttribute("drel")
            if relation_parent!=None:
                relation,parent = relation_parent.split(":")
                tmp.append(relation)
                tmp.append(parent)
                tmp.append(node.lex + "-" + str(node_index))
                node_name[node.getAttribute('name')] = [node.lex,node_index]
                chunk_id[node.getAttribute('chunkId')] = [node.lex,node_index]
                node_index += 1
            else:
                tmp.append('root')
                tmp.append('ROOT-0')
                tmp.append(node.lex + '-' + str(node_index))
                node_name[node.getAttribute('name')] = [node.lex,node_index]
                chunk_id[node.getAttribute('chunkId')] = [node.lex,node_index]
                node_index += 1
            parse_output['dependencies'].append(tmp)
    #print parse_output['dependencies']
    #print "chunkid"
    #print chunk_id
    #print "\npos"
    #print pos
        for index in range(0,len(parse_output['dependencies'])):
            rel = parse_output['dependencies'][index]
            if rel[0]!="root":
                try:
                    parse_output['dependencies'][index][1] = node_name[rel[1]][0] + "-" + str(node_name[rel[1]][1])
                except:
                    parse_output['dependencies'][index][1] = chunk_id[rel[1]][0] + "-" + str(chunk_id[rel[1]][1])
    
        parse_output['words'] = []
        split_sen = sen.split();
        char_start = 0;
        #print len(split_sen)
        for wrd_index in range(0,len(split_sen)):
            #print wrd_index
            tmp = []
            tmp.append(split_sen[wrd_index])
            temp_dict = {}
            temp_dict['PartOfSpeech'] = pos[wrd_index]
            temp_dict['Lemma'] = lemma[wrd_index]
            temp_dict['ChunkType'] = chunk_type[wrd_index]
            temp_dict['NamedEntityTag'] = "O"
            temp_dict['CharacterOffsetBegin'] = str(char_start)
            temp_dict['CharacterOffsetEnd'] = str(char_start + len(split_sen[wrd_index]))
            char_start += len(split_sen[wrd_index]) + 1
            tmp.append(temp_dict)
            parse_output['words'].append(tmp)
        all_sen.append(parse_output)
    """
    #print parse_output

    print "text"
    print parse_output['text'].decode('utf-8')
    print "dependencies"
    for rel in parse_output['dependencies']:
        print rel[0],
        print rel[1],
        print rel[2]
    print 'words'
    for rel in parse_output['words']:
        print rel[0].decode('utf-8'),#word
        print rel[1]['PartOfSpeech'],
        print rel[1]['Lemma']
        print rel[1]['CharacterOffsetBegin']
        print rel[1]['CharacterOffsetEnd']
    """
    return all_sen

if __name__ == "__main__":

    os.system("perl -C /home/darshan/tools/convertor-indic-1.5.2/convertor_indic.pl -f=ssf -l=hin -s=utf -t=wx -i=" + str(sys.argv[1]) + " > /tmp/inp.txt")
    curr_dir = os.getcwd()
    f = codecs.open('/tmp/chunk_expand.txt','w',encoding='utf-8')
    f.close()
    os.chdir("/home/darshan/sampark/Chunk_Expander-1.7")
    #os.system('pwd')
    #if os.path.isfile('/tmp/chunk_expand.txt'):
     #   print 'yes'
      #  os.remove('/tmp/chunk_expand.txt')
    #cmd = "bash $expa/src/run_expander_new.sh /tmp/dep_out.txt /tmp/chunk_expand.txt $expa/grammar/grammar-hindi.json"
    cmd = "sh $expa/expander.sh /tmp/inp.txt /tmp/chunk_expand.txt"
    os.system(cmd)
    os.chdir(curr_dir)
    #for line in open('inp.txt'):
    file_p = open('inp.txt','r')
    file_lines = file_p.readlines()
    file_p.close()

    a = ssf_to_dic("/tmp/chunk_expand.txt")
    for i in a:
        print i

