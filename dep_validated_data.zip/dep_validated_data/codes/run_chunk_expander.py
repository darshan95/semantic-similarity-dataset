#**************convert utf to wx and then run chunk expander8*******************************************

import sys
from os import listdir
from os.path import isfile, join
from ssfAPI_minimal import *
import collections


#file_name ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_final_311.txt"
#file_name ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_root.txt"
#file_name ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/af_added_15feb"
#os.system("converter-indic --f ssf --t inter --l hin --s utf --i " + file_name + " --o /tmp/inp.txt")
#os.system('perl -C /home/darshan/tools/utf2wx/convertor/hin/convertor.pl -f=ssf -l=hin -s=utf -t=wx -i=' + file_name + ' > inp.txt')

file_name ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/afadded17feb"


curr_dir = os.getcwd()
os.chdir("/home/darshan/tools/Shift-Reduce-Chunk-Expander/src")
#os.system("python chunk_expander.py --input /tmp/inp.txt --output /home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_final_expanded1.txt --log log --grammar ../grammar/grammar-hindi-v1.json")
#os.system("python chunk_expander.py --input /tmp/inp.txt --output /home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_final_expanded18feb.txt --log log --grammar ../grammar/grammar-hindi-v1.json")
os.system("python chunk_expander.py --input " + file_name + " --output /home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_final_expanded18feb.txt --log log --grammar ../grammar/grammar-hindi-v1.json")
