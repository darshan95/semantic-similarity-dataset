#***********convert bis to ilmt and correct the sentence IDs according to file numbers and add "af" attribute to the sentences and run morph analyzer to get the root word*************

import sys,codecs
from os import listdir
from os.path import isfile, join
from ssfAPI_minimal import *
import collections
#folder ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_all_files"

folder1 ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/ilmt_dep_validated"
#folder1 ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/codes/temp"
#os.chdir("/home/darshan/tools/HINDI_BIS_ILMT")
#os.system("./extract.py -i " + folder + " -o " + folder1 + " -m map.xml -w wordlist/BIS_wordlist/")

files = [ f for f in listdir(folder1) if isfile(join(folder1,f)) ]
file_no = {}
for f in files:
    b = f.split(".")[0]
    if "-" in b:
        b = b.split("-")[0]
    file_no[int(b)] = f

sorted_files = collections.OrderedDict(sorted(file_no.items()))
fg = codecs.open('morph_inp.txt','wa',encoding='utf')
for file_no in sorted_files:
    prev = 0
    cnt = file_no
    curr_file = sorted_files[file_no]
    curr_dir = os.getcwd()
    file_name = join(folder1,curr_file)
    os.system('perl -C /home/darshan/tools/utf2wx/convertor/hin/convertor.pl -f=ssf -l=hin -s=utf -t=wx -i=' + file_name + ' > /tmp/inp.txt')
    #d = Document(join(folder1,curr_file))
    d = Document('/tmp/inp.txt')
    #print curr_file
    for tree in d.nodeList:
        if prev==0:
            prev = tree.name
            tree.updatenameAttribute(cnt) 
        elif int(tree.name)!=int(prev):
  #          print tree.name,
 #           print prev
            prev = tree.name
            cnt += 1
            tree.updatenameAttribute(cnt)
        elif int(tree.name)==int(prev):
            prev = tree.name
#            print "same"
            tree.updatenameAttribute(cnt)
        for chunk in tree.nodeList:
            #print chunk.getAttribute('head')
            for node in chunk.nodeList:
                """
                try:
                    fg.write('1 ' + str(node.lex)+"\n")
                except:
                    fg.write('1 '+ str(file_no)+"\n")
                """
                """
                fp = codecs.open('/tmp/node_inp.txt','w',encoding='utf')
                fp.write(node.lex)
                fp.close()
                os.system('perl -C /home/darshan/tools/utf2wx/convertor/hin/convertor.pl -f=text -l=hin -s=utf -t=wx -i=/tmp/node_inp.txt > /tmp/node_out.txt')
                fp = open('/tmp/node_out.txt','r')
                wrd = fp.readline()[:-1]
                fp.close()
                """

                flag = 0
                try:
                    pattern = re.compile(r"[A-Za-z0-9]")
                    for char in node.lex:
                        m = pattern.match(char)
                        if not m:
                            flag = 1
                            break
                    if flag==0:
                        fp = open('/tmp/morph_inp.txt','w')
                        fp.write('1 ' + str(node.lex))
                        fp.close()
                        os.system('bash $setu/bin/sl/morph/hin/morph.sh /tmp/morph_inp.txt > /tmp/morph_out.txt')
                        fp = open('/tmp/morph_out.txt','r')
                        morph_out = fp.readlines()
                        fp.close()
                except:
                    a=1
                #root_wrd = morph_out[1].split('\t')[3].split()[1].split('=')[1].split(',')[0][1:]
                try:
                    if flag==0:
                        morph = morph_out[1].split('\t')[3]
                        if "|" in morph:
                            morph = morph.split('|')[0]
                        #print morph
                        morph = morph.split('=')[1][:-1]
                        if morph[-1]=='>':
                            morph = morph[:-1]
                        morph = morph[1:-1]
                        if "," not in morph:
                            morph = ",,,,,,,"
                    else:
                        morph = str(node.lex) + ',,,,,,,'
                except:
                    morph = ",,,,,,,"
                    #print morph[1:-1]

                try:
                    #node.addAttribute('af', node.lex + ',,,,,,,')
                    node.addAttribute('af', morph)
                except:
                    node.addAttribute('af',',,,,,,,')
            try:
                chunk.addAttribute('af',morph)
                #chunk.addAttribute('af',node.lex + ',,,,,,,')
            except:
                chunk.addAttribute('af',',,,,,,,')
              #  sen.append(node.lex)
            #sentence = ' '.join(sen)
            #print chunk.text
        try:
            print tree.printSSFValue(allFeat=False)
        except:
            print "error " + str(tree.name)

fg.close()
