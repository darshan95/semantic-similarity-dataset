from ssfAPI_minimal import *
import sys

d = Document(sys.argv[1])
for tree in d.nodeList:
    for chunk in tree.nodeList:
        for node in chunk.nodeList:
            print node.lex
            if node.lex==",":
                node.updatelex("COMMA")
                node.updatename("COMMA")
    print tree.printSSFValue(allFeat=False)
