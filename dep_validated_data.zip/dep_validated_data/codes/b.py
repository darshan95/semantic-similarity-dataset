import sys
from os import listdir
from os.path import isfile, join
from ssfAPI_minimal import *
import collections
#folder ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/dep_validated_all_files"


folder1 ="/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/ilmt_dep_validated"
#os.chdir("/home/darshan/tools/HINDI_BIS_ILMT")
#os.system("./extract.py -i " + folder + " -o " + folder1 + " -m map.xml -w wordlist/BIS_wordlist/")

files = [ f for f in listdir(folder1) if isfile(join(folder1,f)) ]

file_no = {}
for f in files:
    b = f.split(".")[0]
    if "-" in b:
        b = b.split("-")[0]
    file_no[int(b)] = f

sorted_files = collections.OrderedDict(sorted(file_no.items()))

print sorted_files

for i in sorted_files:
    print i,
