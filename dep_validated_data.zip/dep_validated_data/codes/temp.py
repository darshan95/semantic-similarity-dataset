import sys,codecs
from os import listdir
from os.path import isfile, join
from ssfAPI_minimal import *
import collections
#
if True:
    os.system('perl -C /home/darshan/tools/utf2wx/convertor/hin/convertor.pl -f=ssf -l=hin -s=utf -t=wx -i=/home/darshan/new_hin_monolingual-word-aligner/semantic_sim_data/new_data/dep_validated_data/a.txt > /tmp/inp.txt')
    d = Document('/tmp/inp.txt')
    #print curr_file
    for tree in d.nodeList:
        """
        if prev==0:
            prev = tree.name
            tree.updatenameAttribute(cnt) 
        elif int(tree.name)!=int(prev):
  #          print tree.name,
 #           print prev
            prev = tree.name
            cnt += 1
            tree.updatenameAttribute(cnt)
        elif int(tree.name)==int(prev):
            prev = tree.name
#            print "same"
            tree.updatenameAttribute(cnt)
        """
        for chunk in tree.nodeList:
            #print chunk.getAttribute('head')
            for node in chunk.nodeList:
                """
                fp = codecs.open('/tmp/node_inp.txt','w',encoding='utf')
                fp.write(node.lex)
                fp.close()
                os.system('perl -C /home/darshan/tools/utf2wx/convertor/hin/convertor.pl -f=text -l=hin -s=utf -t=wx -i=/tmp/node_inp.txt > /tmp/node_out.txt')
                fp = open('/tmp/node_out.txt','r')
                wrd = fp.readline()[:-1]
                fp.close()
                """
                try:
                    fp = open('/tmp/morph_inp.txt','w')
                    fp.write('1 ' + str(node.lex))
                    fp.close()
                    os.system('bash $setu/bin/sl/morph/hin/morph.sh /tmp/morph_inp.txt > /tmp/morph_out.txt')
                    fp = open('/tmp/morph_out.txt','r')
                    morph_out = fp.readlines()
                    fp.close()
                except:
                    a=1
                #root_wrd = morph_out[1].split('\t')[3].split()[1].split('=')[1].split(',')[0][1:]
                try:
                    morph = morph_out[1].split('\t')[3]
                    if "|" in morph:
                        morph = morph.split('|')[0]
                    #print morph
                    morph = morph.split('=')[1][:-1]
                    if morph[-1]=='>':
                        morph = morph[:-1]
                    morph = morph[1:-1]
                    if "," not in morph:
                        morph = ",,,,,,,"
                except:
                    morph = ",,,,,,,"
                    #print morph[1:-1]
                try:
                    #node.addAttribute('af', root_wrd + ',,,,,,,')
                    node.addAttribute('af', morph)
                except:
                    node.addAttribute('af',',,,,,,,')
            try:
                chunk.addAttribute('af',morph)
            except:
                chunk.addAttribute('af',',,,,,,,')
              #  sen.append(node.lex)
            #sentence = ' '.join(sen)
            #print chunk.text
        try:
            print tree.printSSFValue(allFeat=False)
        except:
            print "error " + str(tree.name)
