import codecs
fp = codecs.open('o.txt','wa')
for line in codecs.open('222.txt','r'):
    line.replace('<200d>','')
    fp.write(line)

fp.close()
